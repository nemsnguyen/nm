# Block – Tailwind CSS HTML Template Free

#### Preview

 - [Demo](https://themewagon.github.io/block/)

#### Download
 - [Download from ThemeWagon](https://themewagon.com/themes/block/)

## Getting Started

1. Clone Repository
```
git clone https://github.com/themewagon/block.git
```
2. Install Dependencies
```
npm i
```
3. Run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

## Author 
```
Design and code is completely written by CodesCandy and development team. 
```

## License

 - Design and Code is Copyright &copy; <a href="https://codescandy.com/" target="_blank">CodesCandy</a>
 - Licensed cover under [MIT]
 - Distributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a>
